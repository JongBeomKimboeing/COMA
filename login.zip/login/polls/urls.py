from django.urls import path
from polls import views
from polls.views import *


app_name = 'polls'
urlpatterns=[
        path('',views.index,name='index'),
        path('<int:question_id>/',views.detail,name='detail'),
        path('<int:question_id>/results/',views.results,name='results'),
        path('<int:question_id>/vote/',views.vote,name='vote'),
        path('notice/',views.noticeLV.as_view(),name='noticeLV'),
        path('notice/<slug>/',views.noticeDV.as_view(),name='noticeDV'),
        # Example: /album/, same as /
        path('album/', views.AlbumLV.as_view(), name='album_list'),
        # Example: /album/99/
        path('album/<int:pk>/', views.AlbumDV.as_view(), name='album_detail'),
        # Example: /photo/99/
        path('photo/<int:pk>/', views.PhotoDV.as_view(), name='photo_detail'),
        ]


