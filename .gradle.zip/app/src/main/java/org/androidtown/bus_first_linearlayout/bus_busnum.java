package org.androidtown.bus_first_linearlayout;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URL;

public class bus_busnum extends AppCompatActivity {
    EditText editbusnum;
    TextView text;


    String Key="zlpV8fd%2F%2FDn9GbT4DgnZMdNEmetRM7Jufa1h5YvcaeyFBmmf21tsoj0UO0aCITVa5I8QCOBS1vuD9txKFlQcSg%3D%3D";
    String data;
    String citycode;
    String busnum;
    String busId;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bus_busnum);
        editbusnum =(EditText)findViewById(R.id.busnumber);
        text=(TextView)findViewById(R.id.contents);
    }
    public void onButton1clicked(View v) {
        switch (v.getId()) {
            case R.id.search:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        data = getbusway();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                text.setText(data);
                            }
                        });


                    }
                }).start();
                break;

        }
    }
    String getbusID(){ // 도시코드와 버스 번호 받아서 버스 ID리턴하는 함수
        StringBuffer buffer2=new StringBuffer();
        busnum = editbusnum.getText().toString();
        String getbusIDUrl=
                "http://openapi.tago.go.kr/openapi/service/BusRouteInfoInqireService/getRouteNoList?cityCode="+
                        citycode+"&routeNo="+busnum+"&serviceKey="+Key;

        try{
            URL url_2=new URL(getbusIDUrl);
            InputStream is=url_2.openStream();
            XmlPullParserFactory bus1 = XmlPullParserFactory.newInstance();
            XmlPullParser app = bus1.newPullParser();
            app.setInput(new InputStreamReader(is, "UTF-8"));

            String tag2;
            app.next();

            int eventType2=app.getEventType();
            while(eventType2 !=XmlPullParser.END_DOCUMENT){
                switch (eventType2) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer2.append("파싱 시작...\n\n");
                        break;
                    case XmlPullParser.START_TAG:
                        tag2 = app.getName();
                        if (tag2.equals("item")) ;
                        else if (tag2.equals("routeid")) { // 버스 id 부분 버퍼에 저장.
                            app.next();
                            buffer2.append(app.getText());
                        }
                    case XmlPullParser.TEXT:
                        break;
                    case XmlPullParser.END_TAG:
                        tag2 = app.getName();
                        break;
                }
                eventType2 = app.next();


            }
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        }
        buffer2.append("파싱끝\n");
        busId= buffer2.toString();

        return busId;
    }

    String getbusway() { // 버스ID와 도시코드받아서 정류소노선 출력
        StringBuffer buffer = new StringBuffer();

       String busid=getbusID();//버스 id받아오기

        String getbuswayUrl =
                "http://openapi.tago.go.kr/openapi/service/BusRouteInfoInqireService/getRouteAcctoThrghSttnList?&pageNo=1&cityCode=" +
                        citycode + "&routeId=" + busid + "&serviceKey=" + Key;

        try {

            URL url = new URL(getbuswayUrl);
            InputStream is = url.openStream();

            XmlPullParserFactory busstop = XmlPullParserFactory.newInstance();
            XmlPullParser xpp = busstop.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8"));

            String tag;
            xpp.next();
            int eventType = xpp.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                switch (eventType) {
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;
                    case XmlPullParser.START_TAG:
                        tag = xpp.getName();
                        if (tag.equals("item")) ;
                        else if (tag.equals("nodenm")) {
                            buffer.append("정류소 명 : ");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        } else if (tag.equals("nodeord")) {
                            buffer.append("정류소 번호 : ");
                            xpp.next();
                            buffer.append(xpp.getText());
                            buffer.append("\n");
                        }
                        break;
                    case XmlPullParser.TEXT:
                        break;
                    case XmlPullParser.END_TAG:
                        tag = xpp.getName();
                        if (tag.equals("item")) buffer.append("\n");
                        break;
                }
                eventType = xpp.next();
            }


        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        } catch (XmlPullParserException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        buffer.append("파싱끝\n");
        return buffer.toString();
    }


    }









