from __future__ import unicode_literals
from django.utils.encoding import python_2_unicode_compatible
from django.db import models
from django.urls import reverse
from polls.fields import ThumbnailImageField
from django.contrib.auth.models import User


class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def __str__(self): #__Str__ on Python 3
        return self.question_text


class Choice(models.Model):
    question = models.ForeignKey(
            Question,
            on_delete=models.PROTECT)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __str__(self): #__str__ on Python 3
        return self.choice_text

class Notice(models.Model):
    title=models.CharField(max_length=200)
    slug=models.SlugField('SLUG',unique=True,allow_unicode=True,help_text='one word for tile alias')
    content= models.TextField('CONTENT')
    create_date=models.DateTimeField('Create Date',auto_now=True)
    modify_date=models.DateTimeField('Modify Date',auto_now=True)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return  reverse('polls:notice_detail',args=(self.slug,))

    def __str__(self):
        return self.content


class Goal(models.Model):
    title=models.CharField(max_length=200)
    slug=models.SlugField('SLUG',unique=True,allow_unicode=True,help_text='one word for tile alias')
    content= models.TextField('CONTENT')
    create_date=models.DateTimeField('Create Date',auto_now=True)
    modify_date=models.DateTimeField('Modify Date',auto_now=True)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return  reverse('polls:goal_detail',args=(self.slug,))

    def __str__(self):
        return self.content

@python_2_unicode_compatible
class Album(models.Model):
    name = models.CharField(max_length=50)
    description = models.CharField('One Line Description', max_length=100, blank=True)
    owner = models.ForeignKey(User, null=True,on_delete=models.CASCADE,)

    class Meta:
        ordering = ['name']

    def __str__(self):
        return self.name

    def get_absolute_url(self):
        return reverse('polls:album_detail', args=(self.id,))


@python_2_unicode_compatible
class Photo(models.Model):
    album = models.ForeignKey(Album,on_delete=models.CASCADE,)
    title = models.CharField(max_length=50)
    image = ThumbnailImageField(upload_to='photo/%Y/%m')
    description = models.TextField('Photo Description', blank=True)
    upload_date = models.DateTimeField('Upload Date', auto_now_add=True)
    owner = models.ForeignKey(User, null=True,on_delete=models.CASCADE,)

    class Meta:
        ordering = ['title']

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('polls:photo_detail', args=(self.id,))


# Create your models here.
