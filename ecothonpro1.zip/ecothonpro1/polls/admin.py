from django.contrib import admin
from polls.models import Question, Choice, Notice,Goal
from polls.models import Album, Photo
# Register your models here.


#admin.site.register(Notice)


class NoticeAdmin(admin.ModelAdmin):
    list_display = ('title', 'modify_date')
    list_filter = ('modify_date',)
    search_fields = ('title', 'content')
    prepopulated_fields = {'slug':('title',)}


class GoalAdmin(admin.ModelAdmin):
    list_display = ('title', 'modify_date')
    list_filter = ('modify_date',)
    search_fields = ('title', 'content')
    prepopulated_fields = {'slug':('title',)}

class PhotoInline(admin.StackedInline):
    model = Photo
    extra = 2

class AlbumAdmin(admin.ModelAdmin):
    inlines = [PhotoInline]
    list_display = ('name', 'description')

class PhotoAdmin(admin.ModelAdmin):
    list_display = ('title', 'upload_date')

admin.site.register(Album, AlbumAdmin)
admin.site.register(Photo, PhotoAdmin)

admin.site.register(Question)
admin.site.register(Choice)

admin.site.register(Notice,NoticeAdmin)
admin.site.register(Goal,GoalAdmin)