package org.myapp.test;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.JsonReader;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;


import org.jsoup.Connection;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity{
    private static Thread thread = null;
    // 웹사이트 주소를 저장할 변수
    String urlAddress = "http://210.126.49.104:8888/polls/photo/24/";

    URL url;
    HttpURLConnection conn;
    InputStream is;
    ArrayList<Bitmap> bitmaps = new ArrayList<>();

    ArticleParser articleParser;

    ImageView imageView;
    TextView textView, state;

    ArrayList<String> array;

    Elements contents, imgs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = (ImageView)findViewById(R.id.imageView1);
        textView = (TextView)findViewById(R.id.textView1);
        textView.setMovementMethod(new ScrollingMovementMethod());
        state = (TextView)findViewById(R.id.textView);

        articleParser = new ArticleParser();
        Runnable task = new Runnable(){
            public void run(){
                articleParser.execute(urlAddress);
            }
        };

        thread = new Thread(task);
        thread.start();  // 반드시 쓰레드를 해줘야함 그 이유는 아래에서 설명

        try{
            thread.join();  // 쓰레드 작업 끝날때까지 다른 작업들은 대기
        }catch(Exception e){
        }

    }
    List<String> titles = new ArrayList<>();
    List<String> imageUrls = new ArrayList<>();
    int i = 0 ;

    private class ArticleParser extends AsyncTask<String, Void, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try{
                Document store = Jsoup.connect(urlAddress)
                        .timeout(5000)
                        .get();

                textView.setText(store.html());

                contents = store.select("li.title");
                imgs = store.select(".thumbnail");
                for(Element article : contents) {
                    titles.add(article.text());
                    i++;
                }

                for(Element img : imgs){
                    imageUrls.add("http://210.126.49.104:8888"+img.attr("src"));
                }

                try{
                    for(String image : imageUrls) {
                        state.setText(String.valueOf(i));
                        url = new URL(image);
                        conn = (HttpURLConnection) url.openConnection();
                        conn.setDoInput(true);
                        conn.connect();

                        is = conn.getInputStream();
                        bitmaps.add(BitmapFactory.decodeStream(is));
                    }

                }catch (MalformedURLException e){
                    e.printStackTrace();
                    state.setText("예외 1 발생");
                }catch (IOException e){
                    e.printStackTrace();
                    state.setText("예외 2 발생");
                }
            }catch(Exception e){
                e.printStackTrace();
                state.setText("예외 4 발생");
            }

            return null;
        }

        @Override protected void onPostExecute(String s) {
            super.onPostExecute(s);
        }
    }
}
