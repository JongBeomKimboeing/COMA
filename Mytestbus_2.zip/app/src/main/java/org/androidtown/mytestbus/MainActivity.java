package org.androidtown.mytestbus;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class MainActivity extends AppCompatActivity {
    EditText edit;
    TextView TextV;

    String Key="zlpV8fd%2F%2FDn9GbT4DgnZMdNEmetRM7Jufa1h5YvcaeyFBmmf21tsoj0UO0aCITVa5I8QCOBS1vuD9txKFlQcSg%3D%3D";
    String data1;
    String data2;
    String citycode="25";
    String busnum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        edit=(EditText)findViewById(R.id.inputbusnum);
        TextV=(TextView)findViewById(R.id.buscontents);
    }



    public void onButton1Clicked(View v){
        switch (v.getId()){
            case R.id.search:
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        data1=getbusId();
                        data2=getbusWay();
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                               // TextV.setText(data1);
                                TextV.setText(data2);
                            }
                        });
                    }
                }).start();

                break;
        }

    }




    String getbusId(){
        StringBuffer buffer=new StringBuffer();

        busnum=edit.getText().toString();
        //한글을 EditText에서 받을때는 utf-8방식으로 encoding을 해야한다.
        String busIdUrl="http://openapi.tago.go.kr/openapi/service/BusRouteInfoInqireService/getRouteNoList?cityCode=25&routeNo="+busnum+"&serviceKey="+Key;
       // http://openapi.tago.go.kr/openapi/service/BusRouteInfoInqireService/getRouteNoList?cityCode=25&routeNo=5&serviceKey=zlpV8fd%2F%2FDn9GbT4DgnZMdNEmetRM7Jufa1h5YvcaeyFBmmf21tsoj0UO0aCITVa5I8QCOBS1vuD9txKFlQcSg%3D%3D

        try{
            URL getIdUrl =new URL(busIdUrl);
            InputStream is =getIdUrl.openStream();

            XmlPullParserFactory factory=XmlPullParserFactory.newInstance();
            XmlPullParser xpp=factory.newPullParser();
            xpp.setInput(new InputStreamReader(is, "UTF-8"));

            String tag=null;
            xpp.next();
            int eventType=xpp.getEventType();

            while(eventType != XmlPullParser.END_DOCUMENT){
                switch (eventType){
                    case XmlPullParser.START_DOCUMENT:
                        buffer.append("파싱 시작...\n\n");
                        break;
                    case XmlPullParser.START_TAG:
                        tag = xpp.getName();
                        if(tag.equalsIgnoreCase("item"));
                     //   else if(tag.equals("routeid")){
                     //       buffer.append(xpp.getName());
                   //5 }
                    break;
                    case XmlPullParser.TEXT:

                        if(tag.equalsIgnoreCase("routeid")){
                            buffer.append(xpp.getText());
                        }
                            break;
                    case XmlPullParser.END_TAG:
                                tag=xpp.getName();
                                break;
                }
                eventType=xpp.next();
            }

        }catch (Exception e){

        }
        //buffer.append(busnum);
       // buffer.append("\n파싱끝\n");
       // buswayId=buffer.toString();





        return buffer.toString();//buswayId;
    }
   ////////////////////////////////////////////////////////////////////////////////////////
   String getbusWay(){
       StringBuffer buffer=new StringBuffer();

       String buswayUrl="http://openapi.tago.go.kr/openapi/service/BusRouteInfoInqireService/getRouteAcctoThrghSttnList?numOfRows=100&cityCode=25&routeId="+data1+"&serviceKey="+Key;
       // http://openapi.tago.go.kr/openapi/service/BusRouteInfoInqireService/getRouteNoList?cityCode=25&routeNo=5&serviceKey=zlpV8fd%2F%2FDn9GbT4DgnZMdNEmetRM7Jufa1h5YvcaeyFBmmf21tsoj0UO0aCITVa5I8QCOBS1vuD9txKFlQcSg%3D%3D

       try{
           URL getwayUrl =new URL(buswayUrl);
           InputStream is =getwayUrl.openStream();

           XmlPullParserFactory factory=XmlPullParserFactory.newInstance();
           XmlPullParser xpp=factory.newPullParser();
           xpp.setInput(new InputStreamReader(is, "UTF-8"));

           String tag=null;
           xpp.next();
           int eventType=xpp.getEventType();

           while(eventType != XmlPullParser.END_DOCUMENT){
               switch (eventType){
                   case XmlPullParser.START_DOCUMENT:
                       buffer.append("파싱 시작...\n\n");
                       break;
                   case XmlPullParser.START_TAG:
                       tag = xpp.getName();
                       if(tag.equalsIgnoreCase("item"));

                       break;
                   case XmlPullParser.TEXT:

                       if(tag.equalsIgnoreCase("nodenm")){
                           buffer.append(xpp.getText());
                           buffer.append(" ");

                       }
                       if(tag.equalsIgnoreCase("nodeord")){
                           buffer.append(xpp.getText());
                           buffer.append("\n");
                       }
                       break;
                   case XmlPullParser.END_TAG:
                       tag=xpp.getName();
                       break;
               }
               eventType=xpp.next();
           }

       }catch (Exception e){

       }
       //buffer.append(busnum);
       buffer.append("\n파싱끝22\n");





       return buffer.toString();
   }



}

