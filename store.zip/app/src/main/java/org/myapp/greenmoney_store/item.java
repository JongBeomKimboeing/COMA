package org.myapp.greenmoney_store;

public class item {
    public String Name;
    public String Picture;
    public String Price;

    public Item(String name, String pic, String price){
        Name = name;
        Picture = pic;
        Price = price;
    }
}
