package org.androidtown.bus_first_linearlayout;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onButton1Clicked(View v){
        Intent intent = new Intent(getApplicationContext(), bus_busstop.class);
        startActivity(intent);
    }
    public void onButton2Clicked(View v){
        Intent intent = new Intent(getApplicationContext(), bus_busnum.class);
        startActivity(intent);
    }
    public void onButton3Clicked(View v){
        Intent intent = new Intent(getApplicationContext(), bus_reser.class);
        startActivity(intent);
    }
    public void onButton4Clicked(View v){
        Intent intent = new Intent(getApplicationContext(), reserlist.class);
        startActivity(intent);
    }
    public void onButton5Clicked(View v){
        Intent intent = new Intent(getApplicationContext(), set.class);
        startActivity(intent);

    }
  }
