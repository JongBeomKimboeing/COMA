from django.urls import path
from polls import views



app_name = 'polls'
urlpatterns=[
        path('',views.index,name='index'),
        path('<int:question_id>/',views.detail,name='detail'),
        path('<int:question_id>/results/',views.results,name='results'),
        path('<int:question_id>/vote/',views.vote,name='vote'),

        path('notice/',views.noticeLV.as_view(),name='noticeLV'),
        path('notice/<slug>/',views.noticeDV.as_view(),name='noticeDV'),

        path('goal/',views.goalLV.as_view(),name='goalLV'),
        path('goal/<slug>/',views.goalDV.as_view(),name='goalDV'),


        ]



