from django.db import models
from django.urls import reverse
from polls.fields import ThumbnailImageField

class Question(models.Model):
    question_text = models.CharField(max_length=200)
    pub_date = models.DateTimeField('date published')

    def __str__(self): #__Str__ on Python 3
        return self.question_text


class Choice(models.Model):
    question = models.ForeignKey(
            Question,
            on_delete=models.PROTECT)
    choice_text = models.CharField(max_length=200)
    votes = models.IntegerField(default=0)

    def __str__(self): #__str__ on Python 3
        return self.choice_text

class Notice(models.Model):
    title=models.CharField(max_length=200)
    slug=models.SlugField('SLUG',unique=True,allow_unicode=True,help_text='one word for tile alias')
    content= models.TextField('CONTENT')
    create_date=models.DateTimeField('Create Date',auto_now=True)
    modify_date=models.DateTimeField('Modify Date',auto_now=True)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return  reverse('polls:notice_detail',args=(self.slug,))

    def __str__(self):
        return self.content


class Goal(models.Model):
    title=models.CharField(max_length=200)
    slug=models.SlugField('SLUG',unique=True,allow_unicode=True,help_text='one word for tile alias')
    content= models.TextField('CONTENT')
    create_date=models.DateTimeField('Create Date',auto_now=True)
    modify_date=models.DateTimeField('Modify Date',auto_now=True)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return  reverse('polls:goal_detail',args=(self.slug,))

    def __str__(self):
        return self.content







# Create your models here.
