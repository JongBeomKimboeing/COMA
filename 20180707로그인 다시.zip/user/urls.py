from django.urls import path
from user import views



app_name = 'user'
urlpatterns=[

    path('login/',views.logIn.as_view(),name='login'),
    path('signup/',views.signUp.as_view(),name='signup')

        ]



