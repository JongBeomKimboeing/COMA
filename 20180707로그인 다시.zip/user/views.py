from django.http import HttpResponseRedirect, HttpResponse
from django.views import View
from django.shortcuts import get_object_or_404,render
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login
from django.core.exceptions import ObjectDoesNotExist


class signUp(View):
    def get(self,request,*args,**kwargs):
        return render(request, 'user/signup.html')
    def post(self,request,*args,**kwargs):
        condition=False
        response=HttpResponse("Failed Sign Up")
        createID= request.POST['username']
        createPSW=request.POST['psw']
        createPSW2=request.POST['psw.repeat']
        createNAME=request.POST['name']

        try:
            User.objects.get(username=createID)
        except ObjectDoesNotExist:
            condition=True

        if not createPSW==createPSW2:
            response=render(request,'user/signup.html')
            return response
        else:
            user=User.objects.create_user(createID,'',createPSW)
            user.last_name=createNAME
            user.save()
            response=render(request,'user/signup_done.html')
            return response


class logIn(View):
    def get(self,request,*args,**kwargs):
        return render(request,'user/login.html')
    def post(self,request,*args,**kwargs):
        response= HttpResponse("Failed Log IN")
        condition=False
        userID=request.POST['username']
        userPSW=request.POST['psw']
        user=authenticate(username=userID,password=userPSW)

        if user is not None:
            login(request, user)
            response = render(request,'home.html')

        else:
            return response

        return response
