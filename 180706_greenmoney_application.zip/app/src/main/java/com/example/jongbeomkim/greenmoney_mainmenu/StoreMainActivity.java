package com.example.jongbeomkim.greenmoney_mainmenu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class StoreMainActivity extends MenuBar {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.store_main);
    }

    public void onShppingListClicked(View v){
        Intent intent = new Intent(getApplicationContext(), StoreListActivity.class);
        startActivity(intent);
    }

    public void onBackBtnClicked(View v){
        this.finish();
    }

}
