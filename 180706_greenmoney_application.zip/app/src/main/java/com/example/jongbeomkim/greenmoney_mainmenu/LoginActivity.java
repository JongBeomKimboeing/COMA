package com.example.jongbeomkim.greenmoney_mainmenu;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;

public class LoginActivity extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);
    }
    public void onButton1Clicked(View v){
        Intent intent=new Intent(getApplicationContext(),SignupActivity.class);
        startActivity(intent);
    }
    public void onLoginBtnClicked(View v){
        Intent intent=new Intent(getApplicationContext(),MainMenuActivity.class);
        startActivity(intent);
        finish();
    }
}
