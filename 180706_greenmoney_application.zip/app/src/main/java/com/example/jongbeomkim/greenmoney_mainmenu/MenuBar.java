package com.example.jongbeomkim.greenmoney_mainmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public abstract class MenuBar extends AppCompatActivity {
    public void onStoreBtnClicked(View v){
        Intent intent = new Intent(getApplicationContext(), StoreMainActivity.class);
        startActivity(intent);
        finish();
    }
    public void onMainBtnClicked(View v) {
        Intent intent = new Intent(getApplicationContext(), MainMenuActivity.class);
        startActivity(intent);
        finish();
    }
 /*   public void onNoticeBtnClicked(View v) {
        Intent intent = new Intent(getApplicationContext(), bus_busstop.class);
        startActivity(intent);
    }*/
    public void onMissionBtnClicked(View v) {
        Intent intent = new Intent(getApplicationContext(), Mission.class);
        startActivity(intent);
        finish();
    }
 /*   public void onRankingBtnClicked(View v) {
        Intent intent = new Intent(getApplicationContext(), bus_busstop.class);
        startActivity(intent);
    }*/
    public void onMyMenuBtnClicked(View v) {
        Intent intent = new Intent(getApplicationContext(), MyMenu.class);
        startActivity(intent);
    }
}
