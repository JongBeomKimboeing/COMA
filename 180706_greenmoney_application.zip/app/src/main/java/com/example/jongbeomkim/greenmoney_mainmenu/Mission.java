package com.example.jongbeomkim.greenmoney_mainmenu;

import android.os.Bundle;

public class Mission extends MenuBar{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mission);
    }
}
