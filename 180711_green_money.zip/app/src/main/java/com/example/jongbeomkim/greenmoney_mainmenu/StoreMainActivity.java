package com.example.jongbeomkim.greenmoney_mainmenu;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class StoreMainActivity extends MenuBar {

    private static Thread thread = null;

    // 웹사이트 주소를 저장할 변수
    String urlAddress = "http://210.126.49.104:8888/polls/album/";

    ListView listview1, listview2 ;
    ListViewAdapter adapter, adapter2;

    URL url;
    HttpURLConnection conn;
    InputStream is;
    ArrayList<Bitmap> bitmaps = new ArrayList<>();

    List<String> titles = new ArrayList<>();
    List<String> imageUrls = new ArrayList<>();

    ArticleParser articleParser;
    Elements contents, imgs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.store_main);

        articleParser = new ArticleParser();
        Runnable task = new Runnable(){
            public void run(){
                articleParser.execute(urlAddress);
            }
        };

        thread = new Thread(task);
        thread.start();  // 반드시 쓰레드를 해줘야함 그 이유는 아래에서 설명

        try{
            thread.join();  // 쓰레드 작업 끝날때까지 다른 작업들은 대기
        }catch(Exception e){
        }

        // 위에서 생성한 listview에 클릭 이벤트 핸들러 정의.
        listview1.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // get item
                ListViewItem item = (ListViewItem) parent.getItemAtPosition(position) ;

                Bitmap iconDrawable = item.getIcon() ;
                String nameStr = item.getName();

                // TODO : use item data.
            }
        }) ;
        listview2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // get item
                ListViewItem item = (ListViewItem) parent.getItemAtPosition(position) ;

                Bitmap iconDrawable = item.getIcon() ;
                String nameStr = item.getName();

                // TODO : use item data.
            }
        }) ;
    }

    public class ArticleParser extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try{
                Document store = Jsoup.connect(urlAddress)
                        .timeout(5000)
                        .get();

                contents = store.select("h2");
                imgs = store.select(".thumbnail");
                for(Element article : contents) {
                    titles.add(article.text());
                }

                for(Element img : imgs){
                    imageUrls.add("http://210.126.49.104:8888"+img.attr("src"));
                }
            }catch(Exception e){

            }

            // Adapter 생성
            adapter = new ListViewAdapter() ;
            adapter2 = new ListViewAdapter();

            // 리스트뷰 참조 및 Adapter달기
            listview1 = (ListView) findViewById(R.id.ListView1);
            listview2 = (ListView) findViewById(R.id.ListView2);
            listview1.setAdapter(adapter);
            listview2.setAdapter(adapter);

            try{
                for(String image : imageUrls) {
                    url = new URL(image);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true);
                    conn.connect();

                    is = conn.getInputStream();
                    bitmaps.add(BitmapFactory.decodeStream(is));
                }

            }catch (MalformedURLException e){
                e.printStackTrace();
            }catch (IOException e){
                e.printStackTrace();
            }
            int i=0;
            for(String k : titles){
                if(i%2!=0)
                    adapter.addItem(bitmaps.get(i),k) ;
                else
                    adapter2.addItem(bitmaps.get(i),k) ;
                i++;
            }

            return null;
        }
    }

    public void onShoppingListClicked(View v){
        Intent intent = new Intent(getApplicationContext(), StoreListActivity.class);
        startActivity(intent);
    }
}
