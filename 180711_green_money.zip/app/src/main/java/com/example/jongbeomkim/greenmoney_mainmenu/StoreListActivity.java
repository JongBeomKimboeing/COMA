package com.example.jongbeomkim.greenmoney_mainmenu;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class StoreListActivity extends MenuBar{

    private static Thread thread = null;

    // 웹사이트 주소를 저장할 변수
    String urlAddress = "http://210.126.49.104:8888/polls/album/";

    ListView listview;
    ListViewAdapter adapter;

    URL url;
    HttpURLConnection conn;
    InputStream is;
    ArrayList<Bitmap> bitmaps = new ArrayList<>();

    List<String> titles = new ArrayList<>();
    List<String> imageUrls = new ArrayList<>();
    List<String> des = new ArrayList<>();

    ArticleParser articleParser;
    Elements contents, imgs, descriptions;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.storelist);

        articleParser = new ArticleParser();
        Runnable task = new Runnable(){
            public void run(){
                articleParser.execute(urlAddress);
            }
        };

        thread = new Thread(task);
        thread.start();  // 반드시 쓰레드를 해줘야함 그 이유는 아래에서 설명

        try{
            thread.join();  // 쓰레드 작업 끝날때까지 다른 작업들은 대기
        }catch(Exception e){
        }

        listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View v, int position, long id) {
                // get item
                ListViewItem item = (ListViewItem) parent.getItemAtPosition(position) ;

                String titleStr = item.getTitle() ;
                String descStr = item.getDesc() ;
                Bitmap iconDrawable = item.getIcon() ;

                // TODO : use item data.
            }
        }) ;
    }

    private class ArticleParser extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected String doInBackground(String... strings) {
            try{
                Document store = Jsoup.connect(urlAddress)
                        .timeout(5000)
                        .get();

                contents = store.select("#title");
                imgs = store.select("img");
                descriptions = store.select(".content");
                descriptions = descriptions.select("p");

                for(Element article : contents) {
                    titles.add(article.text());
                }

                for(Element count : descriptions){
                    des.add(count.ownText());
                }

                for(Element img : imgs){
                    imageUrls.add("http://210.126.49.104:8888"+img.attr("src"));
                }
            }catch(Exception e){

            }

            // Adapter 생성
            adapter = new ListViewAdapter() ;

            // 리스트뷰 참조 및 Adapter달기
            listview = (ListView) findViewById(R.id.listview1);
            listview.setAdapter(adapter);

            try{
                for(String image : imageUrls) {
                    url = new URL(image);
                    conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true);
                    conn.connect();

                    is = conn.getInputStream();
                    bitmaps.add(BitmapFactory.decodeStream(is));
                }

            }catch (MalformedURLException e){
                e.printStackTrace();
            }catch (IOException e){
                e.printStackTrace();
            }
            int i=0;
            for(String k : titles){
                adapter.addItem(bitmaps.get(i),k, des.get(i)) ;
                i++;
            }

            return null;
        }
    }

    public void onBackButtonClicked(View v){
        finish();
    }
}
