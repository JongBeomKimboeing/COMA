from django.contrib import admin
from polls.models import Question, Choice, Notice,Goal

# Register your models here.


#admin.site.register(Notice)


class NoticeAdmin(admin.ModelAdmin):
    list_display = ('title', 'modify_date')
    list_filter = ('modify_date',)
    search_fields = ('title', 'content')
    prepopulated_fields = {'slug':('title',)}


class GoalAdmin(admin.ModelAdmin):
    list_display = ('title', 'modify_date')
    list_filter = ('modify_date',)
    search_fields = ('title', 'content')
    prepopulated_fields = {'slug':('title',)}

admin.site.register(Question)
admin.site.register(Choice)

admin.site.register(Notice,NoticeAdmin)
admin.site.register(Goal,GoalAdmin)